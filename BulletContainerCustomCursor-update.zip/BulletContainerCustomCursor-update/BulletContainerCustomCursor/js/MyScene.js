class MyScene extends Phaser.Scene {
  /** @type  {Phaser.Types.Input.Keyboard.CursorKeys} */
  cursors
  /** @type {Phaser.Physics.Arcade.Sprite} */
  player 
  /** @type {Phaser.Physics.Arcade.Group} */
  bullets
  /** @type {Phaser.Physics.Arcade.Group} */
  stars
  /** @type {Phaser.Geom.Rectangle} */
  customBounds
  constructor() {
    super('BulletContainer')
  }
  preload() {
    this.load.image('ship', 'assets/bsquadron1.png')
    this.load.image('bullet', 'assets/bullet7.png')
    this.load.image('star', 'assets/star.png')
  }
  create() {
    this.cameras.main.setBounds(0, 0, 800, 600)
    this.physics.world.setBounds(0, 0, 800, 600)
    this.cursors = this.input.keyboard.createCursorKeys()
    this.player = this.physics.add.sprite(this.game.renderer.width/2, this.game.renderer.height/2, 'ship')
    // create a non visible rectangle
    this.customBounds = new Phaser.Geom.Rectangle(200, 150, 400, 300)
    // draw a matching rectangle for debugging purposes
    this.add.graphics().lineStyle(5, 0x00ffff, 0.5).strokeRectShape(this.customBounds)
    this.bullets = this.physics.add.group({
      defaultKey: 'bullet',
      collideWorldBounds: true,
      customBoundsRectangle: this.customBounds, // will collide off custom bounds rectangle rather than world bounds
      maxSize: 3
    })
    this.stars = this.physics.add.group({
      key: 'star',
      quantity: 16,
      bounceX: 1,
      bounceY: 1,
      collideWorldBounds: true,
      velocityX: 300,
      velocityY: 150
    })
    // randomise the position of the stars with a rectangle that matches the games size
    Phaser.Actions.RandomRectangle(this.stars.getChildren(), new Phaser.Geom.Rectangle(0, 0, this.game.renderer.width, this.game.renderer.height));
    // group to group collision
    this.physics.add.overlap(this.bullets, this.stars, this.destroyStar, null, this)
    this.input.on('pointermove', this.rotatePlayer, this)
    this.input.on('pointerdown', this.fireBullet, this)
    // listener for the on worldbounds event - this will just be used for bullets
    this.physics.world.on('worldbounds', this.worldBoundsBullet, this)
    // custom cursor ;-)
    this.input.setDefaultCursor('url(assets/blue.cur), pointer');
  }
  update() {
      // not needed
  }
  rotatePlayer(pointer){
    // make the player rotate towards the pointer
    this.player.rotation = Phaser.Math.Angle.Between(this.player.x, this.player.y, pointer.x, pointer.y)
  }
  fireBullet(){
    // get the first bullet not currently in use - 'in the pool'
    let bullet = this.bullets.get(this.player.x, this.player.y)
    // use if because it might not exist
    if(bullet){
      // force the bullet to trigger the on worldbounds event when it collides with the bounds that have been set - in this case the custom rectangle
      bullet.body.onWorldBounds = true;
      bullet.body.collideWorldBounds = true
      // this seems to be required to prevent a re-firing glitch
      bullet.enableBody(false);
      // make the bullet physics active 
      bullet.setActive(true);
      // make the bullet visible
      bullet.setVisible(true);
      // match the bulet rotation ot the player
      bullet.rotation = this.player.rotation;
      // set the angular velocity of the bullet
      this.physics.velocityFromRotation(bullet.rotation, 400, bullet.body.velocity);
    }
  }
  worldBoundsBullet(body){
    // deactivate bullet - effectively 'returning it to the pool'
    body.gameObject.disableBody(true, true)
  }
  destroyStar(bullet, star){ // even though triggered by group to group collision, the parameters passed back are for the individual colliding group members
    // deactivate bullet
    bullet.disableBody(true, true);
    // permanently remove star
    this.stars.remove(star, true, true)
  }
}
