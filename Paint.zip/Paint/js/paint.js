const canvasContainer = document.getElementById("drawing-area")
let offsetTop
let offsetLeft
const canvas = document.getElementById("my-canvas")
const ctx = canvas.getContext('2d')
let isDrawing = false
let colour = "red"
let brush = "line"
// add mouse listeners
canvas.addEventListener('mousedown', start)
canvas.addEventListener('mousemove', draw)
canvas.addEventListener('mouseup', end)
canvas.addEventListener('mouseleave', end)
// get colour buttons
let colourButtons = document.getElementsByClassName("colselector")
for (let i = 0; i < colourButtons.length; i++) {
    colourButtons[i].addEventListener('click', selectColour)
}
// get clear button
document.getElementById("clear").addEventListener('click', clearCanvas)
// get brushes
let brushButtons = document.getElementsByClassName("brush")
for (let i = 0; i < brushButtons.length; i++) {
    brushButtons[i].addEventListener('click', brushSelection)
}
resizeCanvas()
// all functions below
function brushSelection(event) {
    brush = event.target.parentElement.dataset.tool
}
function clearCanvas() {
    ctx.clearRect(0, 0, canvas.width, canvas.height)
}
function selectColour(event) {
    let style = window.getComputedStyle(event.target)
    colour = style.backgroundColor
}
function start(event) {
    isDrawing = true
    draw(event)
}
function draw(event) {
    if (isDrawing) {
        let x = event.clientX - offsetLeft
        let y = event.clientY - offsetTop
        ctx.lineCap = "round"
        ctx.strokeStyle = colour
        switch (brush) {
            case "line":
                ctx.lineWidth = 15
                ctx.lineTo(x, y)
                ctx.stroke()
                ctx.moveTo(x, y)
                break
            case "circle":
                ctx.lineWidth = 1
                ctx.beginPath()
                ctx.arc(x, y, 50, 0, Math.PI * 2)
                ctx.stroke()
                break

        }
    }
}
function end() {
    isDrawing = false
    ctx.beginPath()

}
function resizeCanvas() {
    let cs = window.getComputedStyle(canvasContainer)
    canvas.width = parseInt(cs.getPropertyValue('width'), 10)
    canvas.height = parseInt(cs.getPropertyValue('height'), 10)
    offsetLeft = canvasContainer.offsetLeft
    offsetTop = canvasContainer.offsetTop
}
