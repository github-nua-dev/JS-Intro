class Shape{
    constructor(x, y, size, fill, stroke){
        this.x = x
        this.y = y
        this.size = size
        this.fill = fill
        this.stroke = stroke
        this.vx = Math.random() * 20 -10
        this.vy = Math.random() * 20 -10
    }
    move(canvas){
        this.x += this.vx
        this.y += this.vy
        if(this.x + this.size/2 > canvas.width){
            this.x = canvas.width - this.size/2
            this.vx = -this.vx
        }else if(this.x < this.size/2){
            this.x = this.size/2
            this.vx = -this.vx
        }
        if(this.y + this.size/2 > canvas.height){
            this.y = canvas.height - this.size/2
            this.vy = -this.vy
        }else if(this.y < this.size/2){
            this.y = this.size/2
            this.vy = -this.vy
        }
    }
}
class Circle extends Shape{
    draw(context){
        context.fillStyle = this.fill
        context.strokeStyle = this.stroke
        context.beginPath()
        context.arc(this.x, this.y, this.size/2, 0, Math.PI * 2)
        context.closePath()
        context.fill()
        context.stroke()
    }
}
class Utils{
    static generateRandomHex(){
        let str ="0123456789ABCDEF"
        let result = "#"
        for(let i = 0; i < 6; i++){
            result += str.charAt(Math.floor(Math.random() * 16))
        }
        console.log("random colour = "+result)
        return result
    }
    static getValidSpawnX(objectSize, availableWidth){
        return (Math.random() * (availableWidth - objectSize)) + objectSize/2
    }
    static getValidSpawnY(objectSize, availableHeight){
        return (Math.random() * (availableHeight - objectSize)) + objectSize/2
    }
}
// global variables
const canvas = document.getElementById("myCanvas")
const context = canvas.getContext("2d")
context.lineWidth = 5
let shapes = []
// initialisation code
initShapes()
render()
// global functions
function render(){
    updateShapes()
    drawShapes()
    requestAnimationFrame(render)
}
function initShapes(){
    let shape
    let size
    let x
    let y
    let fill
    let stroke
    for(let i = 0; i < 10; i++){
        size = Math.random() * 25 + 10
        x = Utils.getValidSpawnX(size, canvas.width)
        y = Utils.getValidSpawnY(size, canvas.height)
        fill = Utils.generateRandomHex()
        stroke = Utils.generateRandomHex()
        // x, y, size, fill, stroke
        shape = new Circle(x, y, size, fill, stroke)
        shapes.push(shape)
    }
}
function updateShapes(){
    for(let i = 0; i < shapes.length; i++){
        shapes[i].move(canvas)
    }
}
function drawShapes(){
    context.clearRect(0, 0, canvas.width, canvas.height)
    for(let i = 0; i < shapes.length; i++){
        shapes[i].draw(context)
    }
}