let x = 100
let y = 100
let radius = 20
let speed = 10
let goingUp = false
let goingDown = false
let goingLeft = false
let goingRight = false
const canvas = document.getElementById("myCanvas")
const context = canvas.getContext("2d")
context.fillStyle = '#FF0000'
// WASD
const upKey = 87
const downKey = 83
const leftKey = 65
const rightKey = 68
// ADD LISTENERS
window.addEventListener('keyup', keyUpHandler)
window.addEventListener('keydown', keyDownHandler)
// INIT LOOP
render()
// GAME LOOP
function render(){
    if(goingUp){
        y -= speed
    }
    if(goingDown){
        y += speed
    }
    if(goingLeft){
        x -= speed
    }
    if(goingRight){
        x += speed
    }
    // correct position based on walls
    if(y - radius < 0){
        // too high
        y = radius
    }else if(y + radius > canvas.height){
        // too low
        y = canvas.height - radius
    }
    if(x - radius < 0){
        // too left
        x = radius
    }else if(x + radius > canvas.width){
        // too right
        x = canvas.width - radius
    }
    // handle collisions (if there were any!)
    // draw
    context.clearRect(0, 0, canvas.width,canvas.height)
    context.beginPath()
    // 360 degrees = Math.PI * 2 radians
    context.arc(x, y, radius, 0, Math.PI * 2)
    context.fill()
    requestAnimationFrame(render)
}
// EVENT HANDLERS
function keyDownHandler(event){
    if(event.keyCode === upKey){
        goingUp = true
    }
    if(event.keyCode === downKey){
        goingDown = true
    }
    if(event.keyCode === leftKey){
        goingLeft = true
    }
    if(event.keyCode === rightKey){
        goingRight = true
    }
}
function keyUpHandler(event){
    if(event.keyCode === upKey){
        goingUp = false
    }
    if(event.keyCode === downKey){
        goingDown = false
    }
    if(event.keyCode === leftKey){
        goingLeft = false
    }
    if(event.keyCode === rightKey){
        goingRight = false
    }
}
