class Circle {
    x
    y
    radius
    speed = 10
    fillColour = '#FF0000'
    goingUp = false
    goingDown = false
    goingLeft = false
    goingRight = false
    upKey
    downKey
    leftKey
    rightKey
    constructor(x, y, r, speed, fillColour) {
        this.x = x
        this.y = y
        this.radius = r
        this.speed = speed
        this.fillColour = fillColour
    }
    updatePos(canvas){
        if(this.goingUp){
            this.y -= this.speed
        }
        if(this.goingDown){
            this.y += this.speed
        }
        if(this.goingLeft){
            this.x -= this.speed
        }
        if(this.goingRight){
            this.x += this.speed
        }
        if(this.y < this.radius){
            this.y = this.radius
        }else if(this.y + this.radius > canvas.height){
            this.y = canvas.height - this.radius
        }
        if(this.x < this.radius){
            this.x = this.radius
        }else if(this.x > canvas.width - this.radius){
            this.x = canvas.width - this.radius
        }
    }
    draw(context){
        context.fillStyle = this.fillColour
        context.beginPath()
        context.arc(this.x, this.y, this.radius, 0, Math.PI * 2)
        context.fill()
    }
    assignKeyCodes(U, D, L, R) {
        this.upKey = U
        this.downKey = D
        this.leftKey = L
        this.rightKey = R
    }
    keyUpHandler(event) {
        if (event.keyCode === this.upKey) {
            this.goingUp = false
        }
        if (event.keyCode === this.downKey) {
            this.goingDown = false
        }
        if (event.keyCode === this.leftKey) {
            this.goingLeft = false
        }
        if (event.keyCode === this.rightKey) {
            this.goingRight = false
        }

    }
    keyDownHandler(event) {
        if (event.keyCode === this.upKey) {
            this.goingUp = true
        }
        if (event.keyCode === this.downKey) {
            this.goingDown = true
        }
        if (event.keyCode === this.leftKey) {
            this.goingLeft = true
        }
        if (event.keyCode === this.rightKey) {
            this.goingRight = true
        }
    }
}
class Utils{
    static generateRandomHex(){
        let str ="0123456789ABCDEF"
        let result = "#"
        for(let i = 0; i < 6; i++){
            result += str.charAt(Math.floor(Math.random() * 16))
        }
        console.log("random colour = "+result)
        return result
    }
}
const canvas = document.getElementById("myCanvas")
const context = canvas.getContext("2d")
let circles = []
for(let i = 0; i < 10; i++){
    let circle = new Circle(Math.random() * canvas.width, 
    Math.random() * canvas.height,
    Math.random() * 50 + 25,
    Math.random() * 100 + 10,
    Utils.generateRandomHex()
    )
    circle.assignKeyCodes(87, 83, 65, 68)
    window.addEventListener("keydown", circle.keyDownHandler.bind(circle))
    window.addEventListener("keyup", circle.keyUpHandler.bind(circle))
    circles[i] = circle
}
render()
function render(){
    // input 
    for(let i = 0; i < circles.length; i++){
        circles[i].updatePos(canvas)
    }
    // collision (not used)
    // draw 
    context.clearRect(0,0,canvas.width, canvas.height)
    for(let i = 0; i < circles.length; i++){
        circles[i].draw(context)
    }
    requestAnimationFrame(render)
}