class Car {
    inForward = false
    inReverse = false
    turnLeft = false
    turnRight = false
    fKey
    bKey
    lKey
    rKey
    constructor(x, y) {
        this.x = x
        this.y = y
    }
    assignKeyCodes(F, B, L, R) {
        this.fKey = F
        this.bKey = B
        this.lKey = L
        this.rKey = R
    }
    keyUpHandler(event) {
        if (event.keyCode == this.fKey) {
            // foot off the gas
            this.inForward = false
        }
        if (event.keyCode == this.bKey) {
            // foot off the gas
            this.inReverse = false
        }
        if (event.keyCode == this.lKey) {
            // turn left
            this.turnLeft = false
        }
        if (event.keyCode == this.rKey) {
            // turn right
            this.turnRight = false
        }
    }
    keyDownHandler(event) {
        if (event.keyCode == this.lKey) {
            // turn left
            this.turnLeft = true
        }
        if (event.keyCode == this.rKey) {
            // turn right
            this.turnRight = true
        }
        if (event.keyCode == this.fKey) {
            // forwards
            this.inForward = true
        }
        if (event.keyCode == this.bKey) {
            // backwards
            this.inReverse = true
        }
    }
}